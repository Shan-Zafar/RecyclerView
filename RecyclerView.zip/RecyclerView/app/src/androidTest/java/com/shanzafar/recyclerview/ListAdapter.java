package com.shanzafar.recyclerview;
import android.support.v7.widget.RecyclerView;
public class ListAdapter extends Apdater{
}
